<<<<<<< HEAD
I Completed my btech in kits college khammam
i work on capgemini company
=======
I Completed my btech in kits college 
im from khammam
>>>>>>> css-assignments
